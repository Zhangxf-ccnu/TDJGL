# Complete algorithm of the TDJGL model. Algorithm 2 in the Supplementary information. 
# For details about the parameters, please refer Section 2.3 in the  Supplementary information.


TDJGL <-
function(X, lam1,lam2, penalize.diagonal = FALSE, weights = "equal", initial.method = "FGL", rho = 1, mu = 10, tau.incr = 2, tau.decr = 2, epsilon.abs = 1e-3, epsilon.rel = 1e-3, maxiter = 200, maxiter.out = 50){
    #
    K <- length(X)
    p <- dim(X[[1]][[1]])[2]
    n <- rep(1,2)
    n[1] <- dim(X[[1]][[1]])[1]
    n[2] <- dim(X[[1]][[2]])[1]
    
    
    # compute sample covariance matrices
    S <- list()
    for(k in seq(K)) {
      
      S[[k]] <- list()
      
      for(c in seq(2)){
        
        X[[k]][[c]] <- scale(X[[k]][[c]], center = TRUE, scale= FALSE)
        
        S[[k]][[c]] <- (1/n[c])*t(X[[k]][[c]]) %*% X[[k]][[c]] 
        # assign feature names if none exist:
        if(length(colnames(X[[k]][[c]])) == 0){
          colnames(S[[k]][[c]]) <- paste("V",1:p,sep="")          
        }else{
          colnames(S[[k]][[c]]) <- colnames(X[[k]][[c]])
        }  
      }  
    }
    
    
    # determine the putative sample size of each class's data.  
    if (weights=="equal"){
      weights <- rep(1,2)
    }else{ 
      if (weights=="sample.size"){
        weights <- n
      }else{
        stop("The weights paremter is wrong","\n")
      }
    }
    
    
    # initialize:
    Theta <- list();
    Z <- Theta;
    
    if (initial.method == "SCov"){
      for (k in seq(K)){
        Theta[[k]] <- list()
        for (c in seq(2)){
          Theta[[k]][[c]] <- solve(S[[k]][[c]] + 0.001*diag(p));
          Z[[k]][[c]]  <- Theta[[k]][[c]] 
        }
      }
    }else{
      if (initial.method == "FGL"){
        for (k in seq(K)){
          temp <- admm.iters(S[[k]], lam1 = lam1,lam2 = lam2, weights = weights, omega = 0.5, psi = 0.5, warm = NULL, penalize.diagonal = penalize.diagonal, rho = rho, mu = mu, tau.incr= tau.incr, tau.decr = tau.decr, epsilon.abs = epsilon.abs, epsilon.rel = epsilon.rel, maxiter = maxiter)
          Theta[[k]] <- temp$Theta
          Z[[k]] <- temp$Z
        }
      }else{
        stop("The initial.method paremter is wrong","\n")
      }  
    }
    
    
    
  
    
    for (i in seq(maxiter.out)){
      
      cat(c("This is the",i,"-th iteration"), "\n")
      
      Theta.old <- Theta
      Z.old <- Z
      
      # compute the weights (omega and psi) in terms of current estimates of paramters 
      omega <- matrix(0, nrow = p, ncol = p)
      psi <- matrix(0, nrow = p, ncol = p)
      
      for (k in seq(K)){
        omega <-  omega +  abs(Theta[[k]][[1]]) +  abs(Theta[[k]][[2]])
        psi <- psi + abs(Theta[[k]][[1]]-Theta[[k]][[2]])
      }
      
      omega <- 0.5 / (sqrt(omega) + 10^(-6))
      psi <- 0.5 / (sqrt(psi) + 10^(-6))   
      
      
      # solve problem (4) by using the Algorithm 1 in the Supplementary information.
      for (k in seq(K)){
        temp <- admm.iters(S[[k]], lam1,lam2, weights = weights, omega = omega, psi = psi, warm = Theta[[k]], penalize.diagonal = penalize.diagonal, rho = rho,
                           mu = mu, tau.incr = tau.incr, tau.decr = tau.decr, epsilon.abs = epsilon.abs, epsilon.rel = epsilon.rel, maxiter = maxiter)
        Theta[[k]] <- temp$Theta
        Z[[k]] <- temp$Z
      }

      
      # convergence criterion
      R_err <- 0
      R_norm <- 0
      for (k in seq(K)){
        for (c in seq(2)){
          R_err <- R_err + sum(sum(abs(Theta[[k]][[c]] - Theta.old[[k]][[c]])))
          R_norm <- R_norm + sum(sum(abs(Theta.old[[k]][[c]])))
        }
      }

      if (R_err < R_norm*epsilon.rel){
        break
      }
      
    }
    
    
    # compute partial correlations
    Rho <- list()
    for (k in seq(K)){
      Rho[[k]] <- list()
      diag_Z <- 0.5*diag(Z[[k]][[1]]) + 0.5*diag(Z[[k]][[2]])
      for (c in seq(2)){
        Rho[[k]][[c]] <- - diag(1/sqrt(diag_Z)) %*% Z[[k]][[c]] %*% diag(1/sqrt(diag_Z))
        diag(Rho[[k]][[c]]) <- 1
      }
    }
    
    out <- list(Theta = Theta, Z = Z, Rho = Rho)
    out
  }






# ADMM algorithm for fused graphical lasso with weighted  \ell 1 penalty (Problem (4) in the Supplementary information). 
# This is the implementary of Algorithm 1 in the  Supplementary information. For details about the parameters, please refer
# to Equation (4) and Algorithm 1 in the Supplementary information.
admm.iters <-
  function(S, lam1,lam2, weights = c(1,1), omega = 1, psi = 1, warm = NULL, penalize.diagonal = FALSE, rho = 1, 
           mu = 10, tau.incr = 2, tau.decr = 2, epsilon.abs = 1e-3, epsilon.rel = 1e-3, maxiter = 200)
  {
    
    p <- dim(S[[1]])[1]
    n <- weights
    
    # Initialize primal variables
    Theta <- list()
    if (is.null(warm)){
      Theta[[1]] <- diag(p)
      Theta[[2]] <- diag(p) 
    }else{
      Theta <- warm
    }
    
    Z <- Theta
    Theta.old <- Theta
    Z.old <- Z
    
    # Initialize dual variables
    U = list()
    U[[1]] <- matrix(0, nrow = p, ncol = p)
    U[[2]] <- matrix(0, nrow = p, ncol = p)
    
    for (i in seq(maxiter)){

      
      #  update Theta by using the Expand operator. Please refer to Section 2.2.1 in the Supplementary information.
      Theta[[1]] <- expand_n(Z[[1]] - (1/rho)*(U[[1]]+n[1]*S[[1]]), rho, n[1])
      Theta[[2]] <- expand_n(Z[[2]] - (1/rho)*(U[[2]]+n[2]*S[[2]]), rho, n[2])
      
      # update Z by using the fused lasso signal approximator. Please refer to Section 2.2.2 in the Supplementary information.
      A <- list()
      A[[1]] <- Theta[[1]] + (1/rho)*U[[1]]
      A[[2]] <- Theta[[2]] + (1/rho)*U[[2]] 
      Z <- flsa2(A, rho, lam1, lam2, omega, psi, penalize.diagonal)
      
      
      
      # updates the dual variables using a dual-ascent update rule.
      U[[1]] <- U[[1]] + rho*(Theta[[1]] - Z[[1]])
      U[[2]] <- U[[2]] + rho*(Theta[[2]] - Z[[2]])
      
      # compute primal residual and dual residual. Please refer to Section 2.2.4 in the Supplementary information.
      Theta.bind <- rbind(Theta[[1]],Theta[[2]])
      Z.bind <- rbind(Z[[1]],Z[[2]])
      Z.old.bind <- rbind(Z.old[[1]],Z.old[[2]])
         
      PR_norm = norm(Theta.bind - Z.bind,'F');
      DR_norm = norm(rho*(Z.bind - Z.old.bind),'F');
   
      
      # Stop criteria. Please refer to Section 2.2.4 in the Supplementary information.
      SC_PR = PR_norm  < (sqrt(2)*p*epsilon.abs + epsilon.rel*max(norm(Theta.bind,'F'),  norm(Z.bind,'F')));
      SC_DR = DR_norm  < (sqrt(2)*p*epsilon.abs + epsilon.rel*norm(rbind(U[[1]],U[[2]]),'F'));
      
      if (SC_PR & SC_DR){
        break
      }
      
      
      
      Z.old <- Z;
      
      # Varying penalty parameter. Please refer to Section 2.2.5 in the Supplementary information.
      if (PR_norm > mu*DR_norm){
        rho = rho*tau.incr}else{
          if (DR_norm > mu*PR_norm){
            rho = rho/tau.decr;
          }}
    }
    
    out <- list(Theta = Theta, Z = Z)
    out
  }




# Fused lasso signal approximator. For details about the parameters, please refer
# to Equation (12) and Section 2.2.2 in the  Supplementary information.

flsa2 <-
  function(A, rho, lam1, lam2, omega, psi, penalize.diagonal)  #A is a list of 2 matrices from which we apply an L2 penalty to departures
  {
    # update Z using Equation (13) in the Supplementary information.
    S1 <- abs(A[[1]]-A[[2]]) <= 2*lam2*psi/rho
    X1 <- (A[[1]]+A[[2]])/2
    Y1 <- X1
    
    S2 <- (A[[1]] > A[[2]]+2*lam2*psi/rho)
    X2 <- A[[1]] - lam2*psi/rho
    Y2 <- A[[2]] + lam2*psi/rho
    
    S3 <- (A[[2]] > A[[1]]+2*lam2*psi/rho)
    X3 <- A[[1]] + lam2*psi/rho
    Y3 <- A[[2]] - lam2*psi/rho
    
    # take a soft-thresholding
    Z <- list()
    Z[[1]] <- soft(a = S1*X1 + S2*X2 + S3*X3, lam = lam1*omega/rho, penalize.diagonal=penalize.diagonal)
    Z[[2]] <- soft(a = S1*Y1 + S2*Y2 + S3*Y3, lam = lam1*omega/rho, penalize.diagonal=penalize.diagonal)
    
    Z
  }



# Expand operator. For details about the parameters, please refer
# to Equation (7) and Section 2.2.1 in the  Supplementary information.
expand_n <-
  function(A, rho, n){
    edecomp <- eigen(A)
    D <- edecomp$values
    U <- edecomp$vectors
    D2 <- 0.5*(D + sqrt(D^2 + 4*n/rho))
    Theta <- U %*% diag(D2) %*% t(U)
    Theta
  }



# Soft-thresholding. For details about the parameters, please refer
# to Section 2.2.2 in the  Supplementary information.
soft <-
  function(a,lam,penalize.diagonal){ # if last argument is FALSE, soft-threshold a matrix but don't penalize the diagonal
    out <- sign(a)*pmax(0, abs(a)-lam)
    if(!penalize.diagonal) diag(out) <- diag(a)
    return(out)
  }

