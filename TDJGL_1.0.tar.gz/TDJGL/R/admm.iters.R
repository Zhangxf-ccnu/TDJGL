admm.iters <-
function(S, lam1,lam2, weights = c(1,1), omega = 1, psi = 1, warm = NULL, penalize.diagonal = FALSE, rho = 1, 
                      mu = 10, tau.incr = 2, tau.decr = 2, epsilon.abs = 1e-3, epsilon.rel = 1e-3, maxiter = 200)
{
  
  p <- dim(S[[1]])[1]
  n <- weights
  
  Theta <- list()
  if (is.null(warm)){
    Theta[[1]] <- diag(p)
    Theta[[2]] <- diag(p) 
  }else{
    Theta <- warm
  }
  
  Z <- Theta
  Theta.old <- Theta
  Z.old <- Z
  
  U = list()
  U[[1]] <- matrix(0, nrow = p, ncol = p)
  U[[2]] <- matrix(0, nrow = p, ncol = p)
  
  for (i in seq(maxiter)){
#     cat(i,"\n")
    
    #     Theta[[1]] <- 0.5*expand_n(Z[[1]] - (1/rho)*(U[[1]]+n[1]*S[[1]]), rho, n[1]) + 0.5*Theta[[1]]
    #     Theta[[2]] <- 0.5*expand_n(Z[[2]] - (1/rho)*(U[[2]]+n[2]*S[[2]]), rho, n[2]) + 0.5*Theta[[2]]
    #     
    
    Theta[[1]] <- expand_n(Z[[1]] - (1/rho)*(U[[1]]+n[1]*S[[1]]), rho, n[1])
    Theta[[2]] <- expand_n(Z[[2]] - (1/rho)*(U[[2]]+n[2]*S[[2]]), rho, n[2])
    
    
    A <- list()
    A[[1]] <- Theta[[1]] + (1/rho)*U[[1]]
    A[[2]] <- Theta[[2]] + (1/rho)*U[[2]] 
    Z <- flsa2(A, rho, lam1, lam2, omega, psi, penalize.diagonal)
    
    #     Z[[1]] = 0.5*Z[[1]] + 0.5*Z.old[[1]]
    #     Z[[2]] = 0.5*Z[[2]] + 0.5*Z.old[[2]]
    
    U[[1]] <- U[[1]] + rho*(Theta[[1]] - Z[[1]])
    U[[2]] <- U[[2]] + rho*(Theta[[2]] - Z[[2]])
    
    Theta.bind <- rbind(Theta[[1]],Theta[[2]])
    Z.bind <- rbind(Z[[1]],Z[[2]])
    Z.old.bind <- rbind(Z.old[[1]],Z.old[[2]])
    
    
    PR_norm = norm(Theta.bind - Z.bind,'F');
    DR_norm = norm(rho*(Z.bind - Z.old.bind),'F');
#     
#     cat(PR_norm,"\n")
#     cat(DR_norm,"\n")
    
    SC_PR = PR_norm  < (sqrt(2)*p*epsilon.abs + epsilon.rel*max(norm(Theta.bind,'F'),  norm(Z.bind,'F')));
    SC_DR = DR_norm  < (sqrt(2)*p*epsilon.abs + epsilon.rel*norm(rbind(U[[1]],U[[2]]),'F'));
    
    if (SC_PR & SC_DR){
      break
    }
    
    
    
    Z.old <- Z;
    
    if (PR_norm > mu*DR_norm){
      rho = rho*tau.incr}else{
        if (DR_norm > mu*PR_norm){
          rho = rho/tau.decr;
        }}
  }
  
  out <- list(Theta = Theta, Z = Z)
  out
}
