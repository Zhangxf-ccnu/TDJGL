TDJGL <-
function(X, lam1,lam2, penalize.diagonal = FALSE, weights = "equal", initial.method = "FGL", rho = 1, mu = 10, tau.incr = 2, tau.decr = 2, epsilon.abs = 1e-3, epsilon.rel = 1e-3, maxiter = 200, maxiter.out = 50){
    ## initialize:
    K <- length(X)
    p <- dim(X[[1]][[1]])[2]
    n <- rep(1,2)
    n[1] <- dim(X[[1]][[1]])[1]
    n[2] <- dim(X[[1]][[2]])[1]
    
    S <- list()
    for(k in seq(K)) {
      
      S[[k]] <- list()
      
      for(c in seq(2)){
        
        X[[k]][[c]] <- scale(X[[k]][[c]], center = TRUE, scale= FALSE)
        
        S[[k]][[c]] <- (1/n[c])*t(X[[k]][[c]]) %*% X[[k]][[c]] 
        # assign feature names if none exist:
        if(length(colnames(X[[k]][[c]])) == 0){
          colnames(S[[k]][[c]]) <- paste("V",1:p,sep="")          
        }else{
          colnames(S[[k]][[c]]) <- colnames(X[[k]][[c]])
        }  
      }  
    }
    
    
    if (weights=="equal"){
      weights <- rep(1,2)
    }else{ 
      if (weights=="sample.size"){
        weights <- n
      }else{
        stop("The weights paremter is wrong","\n")
      }
    }
    
    
    
    Theta <- list();
    Z <- Theta;
    
    if (initial.method == "SCov"){
      for (k in seq(K)){
        Theta[[k]] <- list()
        for (c in seq(2)){
          Theta[[k]][[c]] <- solve(S[[k]][[c]] + 0.001*diag(p));
          Z[[k]][[c]]  <- Theta[[k]][[c]] 
        }
      }
    }else{
      if (initial.method == "FGL"){
        for (k in seq(K)){
          temp <- admm.iters(S[[k]], lam1 = lam1,lam2 = lam2, weights = weights, omega = 0.5, psi = 0.5, warm = NULL, penalize.diagonal = penalize.diagonal, rho = rho, mu = mu, tau.incr= tau.incr, tau.decr = tau.decr, epsilon.abs = epsilon.abs, epsilon.rel = epsilon.rel, maxiter = maxiter)
          Theta[[k]] <- temp$Theta
          Z[[k]] <- temp$Z
        }
      }else{
        stop("The initial.method paremter is wrong","\n")
      }  
    }
    
    
    
  
    
    for (i in seq(maxiter.out)){
      
      cat(c("This is the",i,"-th iteration"), "\n")
      
      Theta.old <- Theta
      Z.old <- Z
      
      
      omega <- matrix(0, nrow = p, ncol = p)
      psi <- matrix(0, nrow = p, ncol = p)
      
      for (k in seq(K)){
        omega <-  omega +  abs(Theta[[k]][[1]]) +  abs(Theta[[k]][[2]])
        psi <- psi + abs(Theta[[k]][[1]]-Theta[[k]][[2]])
      }
      
      omega <- 0.5 / (sqrt(omega) + 10^(-6))
      psi <- 0.5 / (sqrt(psi) + 10^(-6))   
      
      
      for (k in seq(K)){
        temp <- admm.iters(S[[k]], lam1,lam2, weights = weights, omega = omega, psi = psi, warm = Theta[[k]], penalize.diagonal = penalize.diagonal, rho = rho,
                           mu = mu, tau.incr = tau.incr, tau.decr = tau.decr, epsilon.abs = epsilon.abs, epsilon.rel = epsilon.rel, maxiter = maxiter)
        Theta[[k]] <- temp$Theta
        Z[[k]] <- temp$Z
      }
#       
#       for (k in seq(K)){
#         for (c in seq(2)){
#           Theta[[k]][[c]] <-  0.5*Theta[[k]][[c]] + 0.5*Theta.old[[k]][[c]]
#          Z[[k]][[c]] <-  0.5*Z[[k]][[c]] + 0.5*Z.old[[k]][[c]]  
#         }
#       }
#       
      
      
      R_err <- 0
      R_norm <- 0
      for (k in seq(K)){
        for (c in seq(2)){
          R_err <- R_err + sum(sum(abs(Theta[[k]][[c]] - Theta.old[[k]][[c]])))
          R_norm <- R_norm + sum(sum(abs(Theta.old[[k]][[c]])))
        }
      }
      
#    cat(R_err,"\n")  
 #   cat(R_norm,"\n")  
    
    
      if (R_err < R_norm*epsilon.rel){
        break
      }
      
    }
    
    Rho <- list()
    for (k in seq(K)){
      Rho[[k]] <- list()
      diag_Z <- 0.5*diag(Z[[k]][[1]]) + 0.5*diag(Z[[k]][[2]])
      for (c in seq(2)){
        Rho[[k]][[c]] <- - diag(1/sqrt(diag_Z)) %*% Z[[k]][[c]] %*% diag(1/sqrt(diag_Z))
        diag(Rho[[k]][[c]]) <- 1
      }
    }
    
    out <- list(Theta = Theta, Z = Z, Rho = Rho)
    out
  }
