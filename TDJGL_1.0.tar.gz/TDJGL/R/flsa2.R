flsa2 <-
function(A, rho, lam1, lam2, omega, psi, penalize.diagonal)  #A is a list of 2 matrices from which we apply an L2 penalty to departures
  {
    # 1st apply fused penalty:
    S1 <- abs(A[[1]]-A[[2]]) <= 2*lam2*psi/rho
    X1 <- (A[[1]]+A[[2]])/2
    Y1 <- X1
    
    S2 <- (A[[1]] > A[[2]]+2*lam2*psi/rho)
    X2 <- A[[1]] - lam2*psi/rho
    Y2 <- A[[2]] + lam2*psi/rho
    
    S3 <- (A[[2]] > A[[1]]+2*lam2*psi/rho)
    X3 <- A[[1]] + lam2*psi/rho
    Y3 <- A[[2]] - lam2*psi/rho
    
    Z <- list()
    Z[[1]] <- soft(a = S1*X1 + S2*X2 + S3*X3, lam = lam1*omega/rho, penalize.diagonal=penalize.diagonal)
    Z[[2]] <- soft(a = S1*Y1 + S2*Y2 + S3*Y3, lam = lam1*omega/rho, penalize.diagonal=penalize.diagonal)
    
    Z
  }
